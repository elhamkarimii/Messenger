// const express = require('express');
// const bodyParser = require('body-parser')
// const cors = require('cors')
// const app = express();
// app.use(cors());
// app.use(bodyParser.urlencoded({extended:false}));
// app.use(bodyParser.json());
// app.listen(3002);

// app.get('/users', (req, res) =>{
//     return res.send({ name: "eli", number: 3})
// })

// app.post('/add', (req, res) => {
//     res.send({name : 'eee'})
//   })