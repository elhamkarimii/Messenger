import React from "react";
import styled from "styled-components"

const Header = styled.div`
    width: 100%;
    background-color: #32BEA6;  
    height: 87px;
`
const Body = styled.div`

`

export default function HomePage() {
    return(
        <>
            <Body>
                <Header />
            </Body>
        </>
    )
}